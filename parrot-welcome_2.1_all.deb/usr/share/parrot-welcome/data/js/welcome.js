function WelcomeCtrl($scope) {

}
